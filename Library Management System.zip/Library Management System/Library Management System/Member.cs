﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class Member : Form
    {
        DBAccess db = new DBAccess();
        int selectedMemberID = 0;
        public Member()
        {
            InitializeComponent();
        }

       private void btnAdd_Click(object sender, EventArgs e)
{
    string phone = txtPhoneNo.Text.Trim();

    if (txtName.Text == "" || txtGmail.Text == "" || txtPhoneNo.Text == "")
    {
        MessageBox.Show("Please fill all fields");
        return;
    }

    if (phone.Length != 11)
    {
        MessageBox.Show("Phone number must be 11 digits");
        txtPhoneNo.Focus();
        return;
    }

    if (!phone.All(char.IsDigit))
    {
        MessageBox.Show("Phone number must contain digits only");
        txtPhoneNo.Focus();
        return;
    }

    try
    {
        db.OpenConnection();

        // step 1: add the member
        string query = "EXEC sp_AddMember '" + txtName.Text + "', '" + txtGmail.Text + "', '" + txtPhoneNo.Text + "'";
        db.IUD(query);

        // step 2: get the new member id
        SqlDataReader drNew = db.GetData("SELECT TOP 1 MemberID FROM Members ORDER BY MemberID DESC");
        drNew.Read();
        int newMemberID = Convert.ToInt32(drNew["MemberID"]);
        drNew.Close();

        // step 3: call auto assign directly from here
        // trigger was removed because it caused conflict
        db.IUD("EXEC sp_AutoAssignBook " + newMemberID);

        // step 4: get which book was assigned
        DataTable dtAssign = new DataTable();
        SqlDataReader drAssign = db.GetData("EXEC sp_GetAutoAssignedBook " + newMemberID);
        dtAssign.Load(drAssign);

        if (dtAssign.Rows.Count > 0)
        {
            string bookTitle = dtAssign.Rows[0]["BookTitle"].ToString();
            string dueDate   = dtAssign.Rows[0]["DueDate"].ToString();
            MessageBox.Show(
                "Member Added Successfully!\n\n" +
                "Book Auto Assigned:\n" +
                "Book     : " + bookTitle + "\n" +
                "Due Date : " + dueDate,
                "Auto Assign Done",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }
        else
        {
            MessageBox.Show(
                "Member Added Successfully!\n\nNo book was available to assign.",
                "Member Added",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        ClearFields();
        LoadMembers();
        pnlInput.Visible = false;
        pnlGrid.Visible  = true;
    }
    catch (Exception ex)
    {
        MessageBox.Show("Error: " + ex.Message);
    }
    finally
    {
        db.CloseConnection();
    }
}
        private void Member_Load(object sender, EventArgs e)
        {
            LoadMembers();
        }

        private void LoadMembers()
        {
            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_GetAllMembers");
                dt.Load(dr);
                dgvMembers.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (selectedMemberID == 0)
            {
                MessageBox.Show("Please select a member from the list first");
                return;
            }

            try
            {
                db.OpenConnection();
                string query = "EXEC sp_UpdateMember " + selectedMemberID + ", '" + txtName.Text + "', '" + txtGmail.Text + "', '" + txtPhoneNo.Text + "'";
                db.IUD(query);
                MessageBox.Show("Member Updated Successfully");
                ClearFields();
                LoadMembers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedMemberID == 0)
            {
                MessageBox.Show("Please select a member from the list first");
                return;
            }

            DialogResult confirm = MessageBox.Show("Are you sure you want to delete this member?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.No) return;

            try
            {
                db.OpenConnection();
                db.IUD("EXEC sp_DeleteMember " + selectedMemberID);
                MessageBox.Show("Member Deleted Successfully");
                ClearFields();
                LoadMembers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnViewMember_Click(object sender, EventArgs e)
        {
            pnlInput.Visible = false;
            pnlGrid.Visible = true;
            LoadMembers();
         
        }
        private void ClearFields()
        {
            txtMemberID.Text = "";
            txtName.Text = "";
            txtGmail.Text = "";
            txtPhoneNo.Text = "";
            selectedMemberID = 0;
        }

        private void dgvMembers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvMembers.Rows[e.RowIndex];
                selectedMemberID = Convert.ToInt32(row.Cells["MemberID"].Value);
                txtMemberID.Text = row.Cells["MemberID"].Value.ToString();
                txtName.Text = row.Cells["Name"].Value.ToString();
                txtGmail.Text = row.Cells["Gmail"].Value.ToString();
                txtPhoneNo.Text = row.Cells["PhoneNo"].Value.ToString();
            }
        }

   

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string username = Application.UserAppDataRegistry.GetValue("LoggedUser").ToString();
                db.OpenConnection();
                db.IUD("EXEC sp_LogoutUser '" + username + "'");
                db.CloseConnection();
            }
            catch { }

            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookForm book = new BookForm();
            book.Show();
            this.Hide();
        }

        private void btnIssue_Click(object sender, EventArgs e)
        {
            IssueBook book = new IssueBook();
            book.Show();
            this.Hide();
        }

        private void btnreturn_Click(object sender, EventArgs e)
        {
            ReturnBook returnBook = new ReturnBook();
            returnBook.Show();
            this.Hide();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Report report = new Report();
            report.Show();
            this.Hide();
        }

        private void btnMember_Click(object sender, EventArgs e)
        {
            Member member = new Member();
            member.Show();
            this.Hide();
        }
    }
}
