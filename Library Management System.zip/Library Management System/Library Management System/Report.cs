﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class Report : Form
    {
        DBAccess db = new DBAccess();
        public Report()
        {
            InitializeComponent();
        }

        private void Report_Load(object sender, EventArgs e)
        {
            LoadAllBooks();
            LoadIssuedBooks();
            LoadReturnedBooks();
            LoadAllMembers();
        }

        private void LoadAllBooks()
        {
            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_GetAllBooks");
                dt.Load(dr);
                dgvAllBooks.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void LoadIssuedBooks()
        {
            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_GetIssuedBooks");
                dt.Load(dr);
                dgvIssuedBooks.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void LoadReturnedBooks()
        {
            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_GetReturnedBooks");
                dt.Load(dr);
                dgvReturnBooks.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void LoadAllMembers()
        {
            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_GetAllMembers");
                dt.Load(dr);
                dgvAllMembers.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnAllBook_Click(object sender, EventArgs e)
        {
            pnlGrid.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
            panel2.Visible = false;
            LoadAllBooks();
        }

        private void btnIssuedBook_Click(object sender, EventArgs e)
        {
            pnlGrid.Visible =false;
            panel3.Visible = true;
            panel4.Visible = false;
            panel2.Visible = false;
            LoadIssuedBooks();
        }

        private void btnReturnBook_Click(object sender, EventArgs e)
        {
            pnlGrid.Visible = false;
            panel3.Visible = false;
            panel4.Visible = true;
            panel2.Visible = false;
            LoadReturnedBooks();
        }

        private void btnAllMember_Click(object sender, EventArgs e)
        {
            pnlGrid.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel2.Visible = true;
            LoadAllMembers();
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string username = Application.UserAppDataRegistry.GetValue("LoggedUser").ToString();
                db.OpenConnection();
                db.IUD("EXEC sp_LogoutUser '" + username + "'");
                db.CloseConnection();
            }
            catch { }

            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }

    

      

        private void btnIsssue_Click(object sender, EventArgs e)
        {
            IssueBook book = new IssueBook();
            book.Show();
            this.Hide();
        }

        private void bntReturn_Click(object sender, EventArgs e)
        {
            ReturnBook returnBook = new ReturnBook();
            returnBook.Show();
            this.Hide();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Report report = new Report();
            report.Show();
            this.Hide();
        }

        private void btnMember_Click(object sender, EventArgs e)
        {
            Member member = new Member();
            member.Show();
            this.Hide();
        }

        private void btnDashBoard_Click(object sender, EventArgs e)
        {
           DashBoard report = new DashBoard();
            report.Show();
            this.Hide();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookForm book = new BookForm();
            book.Show();
            this.Hide();
        }
    }
}
