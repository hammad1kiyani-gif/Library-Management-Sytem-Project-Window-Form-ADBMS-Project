﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class DashBoard : Form
    {
        DBAccess db = new DBAccess();
        public DashBoard()
        {
            InitializeComponent();
        }

        private void LoadRecentActivity()
        {
            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_GetRecentActivity");

                dt.Load(dr);
                dgvRecentActivity.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading recent activity: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void LoadDashboardStats()
        {

            try
            {
                db.OpenConnection();

           
                lblTotalBooks.Text = db.GetScalar("SELECT ISNULL(SUM(Quantity), 0) FROM Books")?.ToString() ?? "0";

              
                lblMembers.Text = db.GetScalar("SELECT COUNT(*) FROM Members")?.ToString() ?? "0";

               
                lblIssued.Text = db.GetScalar("SELECT COUNT(*) FROM IssuedBooks WHERE Status = 'Issued'")?.ToString() ?? "0";

               
                lblOverdue.Text = db.GetScalar("SELECT COUNT(*) FROM IssuedBooks WHERE Status = 'Issued' AND DueDate < GETDATE()")?.ToString() ?? "0";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading stats: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void DashBoard_Load(object sender, EventArgs e)
        {
            LoadRecentActivity();
            LoadDashboardStats(); 
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            try
            {
                string username = Application.UserAppDataRegistry.GetValue("LoggedUser")?.ToString();
                if (!string.IsNullOrEmpty(username))
                {
                    db.OpenConnection();
                   
                    db.IUD($"EXEC sp_LogoutUser @Username = '{username.Replace("'", "''")}'");
                    db.CloseConnection();
                }
            }
            catch { }

            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookForm book = new BookForm();
            book.Show();
            this.Hide();
        }

        private void btnIssueBook_Click(object sender, EventArgs e)
        {
            IssueBook book = new IssueBook();
            book.Show();
            this.Hide();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Report report = new Report();
            report.Show();
            this.Hide();
        }

        private void btnReturnBook_Click(object sender, EventArgs e)
        {
            ReturnBook returnBook = new ReturnBook();
            returnBook.Show();
            this.Hide();
        }

        private void btnMember_Click_1(object sender, EventArgs e)
        {
            Member member = new Member();
            member.Show();
            this.Hide();
        }

      
    }
}