﻿using System.Data;
using System.Data.SqlClient;
using System.Drawing;

public class DBAccess
{
    static string Constr = "Data Source=DESKTOP-EVQMP6M\\VE_SERVER;Initial Catalog=LibraryManagementDB;Integrated Security=true;TrustServerCertificate=true;";
    SqlConnection Con = new SqlConnection(Constr);
    SqlCommand Cmd = null;
    SqlDataReader Sdr = null;

    public object GetScalar(string query)
    {
        SqlCommand cmd = new SqlCommand(query, Con); 
        return cmd.ExecuteScalar();
    }

    public void OpenConnection()
    {
        if (Con.State == ConnectionState.Closed)
            Con.Open();
    }

    public void CloseConnection()
    {
        if (Con.State == ConnectionState.Open)
            Con.Close();
    }

    public void IUD(string Query)
    {
        Cmd = new SqlCommand(Query, Con);
        Cmd.ExecuteNonQuery();
    }

    public SqlDataReader GetData(string Query)
    {
        Cmd = new SqlCommand(Query, Con);
        Sdr = Cmd.ExecuteReader();
        return Sdr;
    }
}