﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class LoginForm : Form
    {
        DBAccess db = new DBAccess();
        public LoginForm()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUserName.Text))
            {
                MessageBox.Show("Username cannot be empty", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUserName.Focus();
                return;
            }

            if (txtUserName.Text.Length < 3)
            {
                MessageBox.Show("Username must be at least 3 characters", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUserName.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Password cannot be empty", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return;
            }

            if (txtPassword.Text.Length < 4)
            {
                MessageBox.Show("Password must be at least 4 characters", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return;
            }

           
            try
            {
                db.OpenConnection();
                string query = "EXEC sp_LoginUser '" + txtUserName.Text.Trim() + "', '" + txtPassword.Text.Trim() + "'";
                SqlDataReader dr = db.GetData(query);

                if (dr.HasRows)
                {
                    Application.UserAppDataRegistry.SetValue("LoggedUser", txtUserName.Text.Trim());
                    dr.Close();
                    db.CloseConnection();
                    MessageBox.Show("Login Successful! Welcome " + txtUserName.Text, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DashBoard dash = new DashBoard();
                    dash.Show();
                    this.Hide();
                }
                else
                {
                    dr.Close();
                    MessageBox.Show("Invalid Username or Password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPassword.Clear();
                    txtPassword.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            pnlLogin.Visible = true;
            txtUserName.Clear();
            txtPassword.Clear();
            txtUserName.Focus();
        }

        private void txtUserName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;
        }
    }
}
