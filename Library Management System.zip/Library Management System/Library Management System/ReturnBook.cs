﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class ReturnBook : Form
    {
        DBAccess db = new DBAccess();
        int selectedIssueID = 0;
        public ReturnBook()
        {
            InitializeComponent();
        }

        private void ReturnBook_Load(object sender, EventArgs e)
        {
            LoadReturnedBooks();
        }
        private void LoadReturnedBooks()
        {
            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_GetReturnedBooks");
                dt.Load(dr);
                dgvReturnBooks.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            pnlSearch.Visible = true;
            pnlGrid.Visible = true;
            if (txtMemberID.Text == "")
            {
                MessageBox.Show("Please enter Member ID");
                return;
            }

            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_SearchIssuedByMember " + txtMemberID.Text);
                dt.Load(dr);
                dgvReturnBooks.DataSource = dt;

                if (dt.Rows.Count == 0)
                    MessageBox.Show("No issued books found for this member");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnFine_Click(object sender, EventArgs e)
        {
            pnlSearch.Visible = true;
            pnlGrid.Visible = true;
            if (selectedIssueID == 0)
            {
                MessageBox.Show("Please select a record from the list first");
                return;
            }

            try
            {
                db.OpenConnection();
                SqlDataReader dr = db.GetData("SELECT dbo.fn_CalculateFine(" + selectedIssueID + ") AS Fine");
                if (dr.HasRows)
                {
                    dr.Read();
                    txtFine.Text = dr["Fine"].ToString();
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            pnlSearch.Visible = true;
            pnlGrid.Visible = true;
            if (selectedIssueID == 0)
            {
                MessageBox.Show("Please select a record from the list first");
                return;
            }

            if (txtFine.Text == "") txtFine.Text = "0";

            try
            {
                db.OpenConnection();
                string query = "EXEC sp_ReturnBook " + selectedIssueID + ", " + txtFine.Text;
                db.IUD(query);
                MessageBox.Show("Book Returned Successfully");
                ClearFields();
                LoadReturnedBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void dgvReturnBooks_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                  
                DataGridViewRow row = dgvReturnBooks.Rows[e.RowIndex];
                if (row.Cells["IssueID"].Value != null)
                    selectedIssueID = Convert.ToInt32(row.Cells["IssueID"].Value);
                if (row.Cells["MemberName"].Value != null)
                    txtMemberName.Text = row.Cells["MemberName"].Value.ToString();
            }
        }
        private void ClearFields()
        {
            txtMemberID.Text = "";
            txtMemberName.Text = "";
            txtFine.Text = "";
            selectedIssueID = 0;
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string username = Application.UserAppDataRegistry.GetValue("LoggedUser").ToString();
                db.OpenConnection();
                db.IUD("EXEC sp_LogoutUser '" + username + "'");
                db.CloseConnection();
            }
            catch { }

            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }

        private void btnMember_Click(object sender, EventArgs e)
        {
            Member member = new Member();
            member.Show();
            this.Hide();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookForm book = new BookForm();
            book.Show();
            this.Hide();
        }

        private void btnIssue_Click(object sender, EventArgs e)
        {
            IssueBook book = new IssueBook();
            book.Show();
            this.Hide();
        }



        private void btnReport_Click(object sender, EventArgs e)
        {Report report = new Report();
            report.Show();
            this.Hide();
        }

        private void btnReturnBook_Click(object sender, EventArgs e)
        {
          
            ReturnBook returnBook = new ReturnBook();
            returnBook.Show();
            this.Hide();

        }
    }
}
