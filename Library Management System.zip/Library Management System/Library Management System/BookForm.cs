﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Library_Management_System
{
    public partial class BookForm : Form
    {
        
        DBAccess db = new DBAccess();
        int selectedBookID = 0;
        public BookForm()
        {

            InitializeComponent();
          
        }

        private void BookForm_Load(object sender, EventArgs e)
        {

            LoadBooks();
        }
        private void LoadBooks()
        {
            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_GetAllBooks");
                dt.Load(dr);
                dgvBooks.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            pnlInput.Visible = true;
            pnlGrid.Visible = true;
           
            if (txtTitle.Text == "" || txtName.Text == "" || txtAuthor.Text == "" || txtQuantity.Text == "")
            {
                MessageBox.Show("Please fill all fields");
                return;
            }

            try
            {
                db.OpenConnection();
                string query = "EXEC sp_AddBook '" + txtTitle.Text + "', '" + txtName.Text + "', '" + txtAuthor.Text + "', " + txtQuantity.Text;
                db.IUD(query);
                MessageBox.Show("Book Added Successfully");
                ClearFields();
                LoadBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (selectedBookID == 0)
            {
                MessageBox.Show("Please select a book from the list first");
                return;
            }

            try
            {
                db.OpenConnection();
                string query = "EXEC sp_UpdateBook " + selectedBookID + ", '" + txtTitle.Text + "', '" + txtName.Text + "', '" + txtAuthor.Text + "', " + txtQuantity.Text;
                db.IUD(query);
                MessageBox.Show("Book Updated Successfully");
                ClearFields();
                LoadBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedBookID == 0)
            {
                MessageBox.Show("Please select a book from the list first");
                return;
            }

            DialogResult confirm = MessageBox.Show("Are you sure you want to delete this book?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.No) return;

            try
            {
                db.OpenConnection();
                db.IUD("EXEC sp_DeleteBook " + selectedBookID);
                MessageBox.Show("Book Deleted Successfully");
                ClearFields();
                LoadBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnViewBook_Click(object sender, EventArgs e)
        {
            pnlInput.Visible = false;
            pnlGrid.Visible = true;
            LoadBooks();
        }

        private void dgvBooks_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvBooks.Rows[e.RowIndex];
                selectedBookID = Convert.ToInt32(row.Cells["BookID"].Value);
                txtTitle.Text = row.Cells["Title"].Value.ToString();
                txtName.Text = row.Cells["BookName"].Value.ToString();
                txtAuthor.Text = row.Cells["Author"].Value.ToString();
                txtQuantity.Text = row.Cells["Quantity"].Value.ToString();
            }
        }
        private void ClearFields()
        {
            txtTitle.Text = "";
            txtName.Text = "";
            txtAuthor.Text = "";
            txtQuantity.Text = "";
            selectedBookID = 0;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            try
            {
                string username = Application.UserAppDataRegistry.GetValue("LoggedUser").ToString();
                db.OpenConnection();
                db.IUD("EXEC sp_LogoutUser '" + username + "'");
                db.CloseConnection();
            }
            catch { }

            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }

     

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookForm book = new BookForm();
            book.Show();
            this.Hide();
        }

        private void btnIssueBook_Click(object sender, EventArgs e)
        {
            IssueBook book = new IssueBook();
            book.Show();
            this.Hide();
        }

        private void btnReturnBook_Click(object sender, EventArgs e)
        {
            ReturnBook returnBook = new ReturnBook();
            returnBook.Show();
            this.Hide();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Report report = new Report();
            report.Show();
            this.Hide();
        }

        private void btnMember_Click(object sender, EventArgs e)
        {
            Member member = new Member();
            member.Show();
            this.Hide();
        }
    }
}
