﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class IssueBook : Form
    {
        DBAccess db = new DBAccess();
        public IssueBook()
        {
            InitializeComponent();
        }
        private void btnIssueBook_Click(object sender, EventArgs e)
        {
            pnlInput.Visible = true;
            pnlGrid.Visible = true;

            if (txtMemberID.Text == "" || cmbBookName.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill all fields");
                return;
            }

            try
            {
                db.OpenConnection();

                int bookID = Convert.ToInt32(cmbBookName.SelectedValue);

                string query = "EXEC sp_IssueBook "
                    + txtMemberID.Text + ", "
                    + bookID + ", '"
                    + txtDueDate.Value.ToString("yyyy-MM-dd") + "'";

                db.IUD(query);

                MessageBox.Show("Book Issued Successfully");

                ClearFields();
                LoadIssuedBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }
        private void ClearFields()
        {
            txtMemberID.Text = "";
            txtMemberName.Text = "";
            cmbBookName.Text = "";
            txtDueDate.Text = "";
        }

        private void IssueBook_Load(object sender, EventArgs e)
        {
            LoadIssuedBooks();
            LoadBooks();
        }
        private void LoadBooks()
        {
            try
            {
                db.OpenConnection();

                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("SELECT BookID, Title FROM Books");

                dt.Load(dr);

                cmbBookName.DataSource = dt;
                cmbBookName.DisplayMember = "Title";
                cmbBookName.ValueMember = "BookID";

                cmbBookName.SelectedIndex = -1; 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }
        private void LoadIssuedBooks()
        {
            try
            {
                db.OpenConnection();
                DataTable dt = new DataTable();
                SqlDataReader dr = db.GetData("EXEC sp_GetIssuedBooks");
                dt.Load(dr);
                dgvIssuedBooks.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void txtMemberID_Leave(object sender, EventArgs e)
        {
            if (txtMemberID.Text == "") return;

            try
            {
                db.OpenConnection();
                SqlDataReader dr = db.GetData("SELECT Name FROM Members WHERE MemberID = " + txtMemberID.Text);
                if (dr.HasRows)
                {
                    dr.Read();
                    txtMemberName.Text = dr["Name"].ToString();
                }
                else
                {
                    MessageBox.Show("Member not found");
                    txtMemberName.Text = "";
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            try
            {
                string username = Application.UserAppDataRegistry.GetValue("LoggedUser").ToString();
                db.OpenConnection();
                db.IUD("EXEC sp_LogoutUser '" + username + "'");
                db.CloseConnection();
            }
            catch { }

            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookForm book = new BookForm();
            book.Show();
            this.Hide();
        }

     

        private void btnIssue_Click(object sender, EventArgs e)
        {
            IssueBook book = new IssueBook();
            book.Show();
            this.Hide();
        }

        private void btnReturnBook_Click(object sender, EventArgs e)
        {
            ReturnBook returnBook = new ReturnBook();
            returnBook.Show();
            this.Hide();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Report returnBook = new Report();
            returnBook.Show();
            this.Hide();
        }

        private void btnMember_Click(object sender, EventArgs e)
        {
            Member member = new Member();
            member.Show();
            this.Hide();
        }
    }
}
